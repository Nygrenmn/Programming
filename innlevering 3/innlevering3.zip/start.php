<!DOCTYPE html>
<html>
<head>
    <title>Innlevering 3</title>
    <link rel="stylesheet" type="text/css" href="css-i.css"
    media="screen" title="css-i3"/>
</head>

<body class="gbStil">

    <div id="boks">

        <header>
            <h1>Innlevering 3</h1>
        </header>
    
        <nav>
            <h3>Meny</h3>
            <p><a href="index.php">Hjem </a></p>
            <p><a href="registrer-klasse.php">Registrer klasse</a></p>
            <p><a href="vis-alle-klasser.php">Vis alle klasser</a></p>
            <p><a href="slett-klasse.php">Slett klasse</a></p>
            <p><br/></p>
            <p><a href="registrer-student.php">Registrer student</a></p>
            <p><a href="vis-alle-studenter.php">Vis alle studenter</a></p>
            <p><a href="slett-student.php">Slett student</a></p>
        </nav>

        <article>