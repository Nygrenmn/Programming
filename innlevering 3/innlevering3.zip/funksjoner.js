function bekreft()
{
    return confirm("Er du sikker?");
}