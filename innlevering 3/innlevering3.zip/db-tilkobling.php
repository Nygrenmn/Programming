<?php
$vert="localhost";
$bruker="265362";
$passord="dYpX+UW5";
$database="265362";

    $db=mysqli_connect($vert,$bruker,$passord,$database) or die("ikke kontakt med databaseserver")
?>