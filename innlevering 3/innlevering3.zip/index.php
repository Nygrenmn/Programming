<?php
include("start.php");
?>

<h3>Velkommen til startsiden</h3>
Du finner menyen til venstre i denne applikasjonen.

<?php
include("slutt.php");
?>